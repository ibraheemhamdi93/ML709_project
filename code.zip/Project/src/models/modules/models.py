from torch import nn
# import torchvision
from pytorch_lightning import LightningModule
import torchxrayvision as xrv
from timm import create_model

class Models(LightningModule):

    def __init__(self, hparams: dict):
        super().__init__()

        if hparams["model"] in ["RSNA","NIH","PadChest","CheXpert","MIMIC_NB","MIMIC_CH","ALL"]:
            if hparams["model"]=="RSNA":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-rsna", 
                                                drop_rate = hparams["drop_rate"])

            elif hparams["model"]=="NIH":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-nih", 
                                                drop_rate = hparams["drop_rate"])

            elif hparams["model"]=="PadChest":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-pc", 
                                                drop_rate = hparams["drop_rate"])

            elif hparams["model"]=="CheXpert":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-chex", 
                                                drop_rate = hparams["drop_rate"])

            elif hparams["model"]=="MIMIC_NB":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-mimic_nb", 
                                                drop_rate = hparams["drop_rate"])

            elif hparams["model"]=="MIMIC_CH":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-mimic_ch", 
                                                drop_rate = hparams["drop_rate"])

            elif hparams["model"]=="ALL":
                self.model = xrv.models.DenseNet(weights="densenet121-res224-all", 
                                                drop_rate = hparams["drop_rate"])
            # from torchsummary import summary
            # summary(self.model, input_size=(1, 224, 224))
            num_ftrs = self.model.classifier.in_features
            self.model.classifier = nn.Sequential(nn.Linear(num_ftrs, 500),nn.Linear(500, hparams["num_classes"]))
            # print(self.model.classifier)
        
        else:
            self.model = create_model(hparams["model"],pretrained=True,num_classes=hparams["num_classes"])

    def forward(self, x):
        return self.model(x)