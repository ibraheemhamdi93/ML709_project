from typing import Optional, Tuple
import pandas as pd
from pytorch_lightning import LightningDataModule
from torch.utils.data import DataLoader, Dataset
from sklearn.model_selection import train_test_split
from glob import glob
import random

from src.datamodules.datasets.covid2 import Covid


class COVIDDataModule(LightningDataModule):
    """
    A DataModule implements 5 key methods:
        - prepare_data (things to do on 1 GPU/TPU, not on every GPU/TPU in distributed mode)
        - setup (things to do on every accelerator in distributed mode)
        - train_dataloader (the training dataloader)
        - val_dataloader (the validation dataloader(s))
        - test_dataloader (the test dataloader(s))

    This allows you to share a full dataset without explaining how to download,
    split, transform and process the data.

    Read the docs:
        https://pytorch-lightning.readthedocs.io/en/latest/extensions/datamodules.html
    """

    def __init__(
        self,
        data_dir: str = "data/",
        train_val_test_split: Tuple[int, int, int] = (60, 20, 20),
        batch_size: int = 32,
        num_workers: int = 0,
        pin_memory: bool = False,

        csv_name: str = "train_study_level.csv",
        classes: int = 2,
        dataset_size: int = 500,
        normal: int = 1,
        img_size: int = 128,
        model: str = "Densenet121",
        scale: float = 0, 
        shear: float = 0, 
        translation: int = 0,
        horizontal_flip: bool = False,
        vertical_flip: bool = False,
        rotation: int = 0,
        seed: int = 12345,

    ):
        super().__init__()

        self.seed=seed
        self.data_dir = data_dir
        self.batch_size = batch_size
        self.train_val_test_split = train_val_test_split
        self.num_workers = num_workers
        self.pin_memory = pin_memory

        self.csv_name = csv_name
        self.classes = classes
        self.dataset_size = dataset_size
        self.normal = normal
        self.img_size = img_size
        self.model = model
        self.scale = scale
        self.shear = shear
        self.translation = translation
        self.horizontal_flip = horizontal_flip
        self.vertical_flip = vertical_flip
        self.rotation = rotation

        self.transformations={"scale": self.scale, 
                            "shear": self.shear, 
                            "translation": self.translation,
                            "horizontal_flip": self.horizontal_flip,
                            "vertical_flip": self.vertical_flip,
                            "rotation": self.rotation
        }
        
        self.save_hyperparameters()
        
        train_files, valid_files, test_files , negs, typs, indets, atyps = self.preparing_data(path = self.data_dir+self.csv_name)

        self.data_train: Optional[Dataset] = Covid(files = train_files,
                                                negs = negs, 
                                                typs = typs, 
                                                indets= indets, 
                                                atyps = atyps,
                                                data_dir = self.data_dir, 
                                                classes = self.classes, 
                                                model = self.model,
                                                mode='train', 
                                                transformations = self.transformations,
                                                img_size=self.img_size,
                                                )
        self.data_val: Optional[Dataset] = Covid(files = valid_files,
                                                negs = negs, 
                                                typs = typs, 
                                                indets= indets, 
                                                atyps = atyps,
                                                data_dir = self.data_dir,
                                                classes = self.classes, 
                                                model = self.model,
                                                mode='valid',
                                                normal = self.normal,
                                                img_size = self.img_size,
                                                transformations = self.transformations,
                                                )
        self.data_test: Optional[Dataset] = Covid(files = test_files,
                                                negs = negs, 
                                                typs = typs, 
                                                indets= indets, 
                                                atyps = atyps,
                                                data_dir = self.data_dir, 
                                                classes = self.classes, 
                                                model = self.model, 
                                                mode='test', 
                                                normal = self.normal, 
                                                img_size = self.img_size,
                                                transformations = self.transformations,
                                                )

    def preparing_data(self, path: str):
        oset_fol=path[:-((len(path.split("/")[-1])+1))]
        train_dir = oset_fol+'/train'

        df = pd.read_csv(path)

        removed=0
        for index, row in df.iterrows():
            if len(glob(train_dir+"/"+row.id.split('_')[0]+"/*/"))>1:
                df = df.drop(df.index[df["id"] == row.id.split('_')[0]+"_study"])
                removed+=1
        print("Removed",removed,"patients with more than 1 files to eliminate lateral x-rays")

        negs_df=df.loc[df['Negative for Pneumonia']==1]
        typ_df=df.loc[df['Typical Appearance']==1]
        indet_df=df.loc[df['Indeterminate Appearance']==1]
        atyp_df=df.loc[df['Atypical Appearance']==1]

        negs = negs_df["id"].to_list()
        typs = typ_df["id"].to_list()
        indets = indet_df["id"].to_list()
        atyps = atyp_df["id"].to_list()

        files = negs+typs+indets+atyps

        all_files = []

        for file in files:
            filename = file.replace("_study","")
            try:
                file = filename.replace(filename,glob("/home/ibraheem.hamdi/Documents/ML709/Project/data/train/"+filename+"/*/*.dcm")[0])
                all_files.append(file)
            except:
                pass

        random.seed(self.seed)
        random.shuffle(all_files)

        train_files = all_files[:int(self.train_val_test_split[0]/100*len(all_files))]
        valid_files = all_files[int(self.train_val_test_split[0]/100*len(all_files))
                                :int(self.train_val_test_split[0]/100*len(all_files))+int(self.train_val_test_split[1]/100*len(all_files))]
        test_files = all_files[-int(self.train_val_test_split[2]/100*len(all_files)):]

        return train_files, valid_files, test_files , negs, typs, indets, atyps


    @property
    def num_classes(self) -> int:
        return self.classes

    def prepare_data(self):
        """Download data if needed. This method is called only from a single GPU.
        Do not use it to assign state (self.x = y)."""

    def setup(self, stage: Optional[str] = None):
        """Load data. Set variables: `self.data_train`, `self.data_val`, `self.data_test`.
        This method is called by lightning twice for `trainer.fit()` and `trainer.test()`, so be careful if you do a random split!
        The `stage` can be used to differentiate whether it's called before trainer.fit()` or `trainer.test()`."""

    def train_dataloader(self):
        return DataLoader(
            dataset=self.data_train,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            shuffle=True,
        )

    def val_dataloader(self):
        return DataLoader(
            dataset=self.data_val,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            shuffle=False,
        )

    def test_dataloader(self):
        return DataLoader(
            dataset=self.data_test,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            shuffle=False,
        )
